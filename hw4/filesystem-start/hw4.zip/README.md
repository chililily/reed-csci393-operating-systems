# filesystem-start
Starting point for Assignment 4

```
nosetests FileSystem.py
```

Tests my implementation of Assignment 3 (your starting point).

Details of the assignment are on the Moodle.
