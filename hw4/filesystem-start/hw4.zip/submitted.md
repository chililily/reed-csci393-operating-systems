## Assignment 4 status

**Legend**  
[x] complete  
[~] complete w/ bugs (that I know about)   
[o] in progress  
[ ] not started  
  
[x] INode.read
[x] INode.write  
[x] FileSystem.open
[x] FileSystem.unmount
[x] FileSystem.namei
[x] tests
[x] comments  

## Notes  
Any other stopping conditions for read/write? ...

Added directory cache. Block cache as separate class, for organization.

Perms seem kinda wonky. maybe.